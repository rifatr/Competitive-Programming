#include<stdio.h>
int main()
{
    int t, n, i = 0;
    scanf("%d", &t);

    while (i < t) {
        scanf("%d", &n);
        int rem, sum = 0, tem = n;
        while(n > 0){
            rem = n % 10;
            sum = sum * 10 + rem;
            n = n / 10;
        }
        if(sum == tem)
            printf("wins\n");
        else
            printf("losses\n");
        i++;
    }
    return 0;
}
