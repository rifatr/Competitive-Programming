#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t, i, j, m, k = 0;
    scanf("%d", &t);
    char s[10000];
    char r[10000];

    for(i = 0; i < t; i++){
        scanf("%s", s);
       // k = strlen(s);
        strcpy(r, s);
       /* for(m = 0, j = k - 1; m < k, j >= 0; m++, j--){
            r[j] = s[m];
        }*/
        strrev(r);
        if(strcmp(s, r) == 0)
            printf("wins\n");
        else
            printf("losses\n");
    }

    return 0;
}

