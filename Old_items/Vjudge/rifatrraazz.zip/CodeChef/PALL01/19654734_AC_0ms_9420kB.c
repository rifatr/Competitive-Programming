#include<stdio.h>
int main()
{
    int t, n, i = 0;
    scanf("%d", &t);
    int flag[t];

    while (i < t) {
        scanf("%d", &n);
        int rem, sum = 0, tem = n;
        while(n > 0){
            rem = n % 10;
            sum = sum * 10 + rem;
            n = n / 10;
        }
        if(sum == tem)
            flag[i] = 1;
        else
            flag[i] = 0;
        i++;
    }
    for(i = 0; i < t; i++){
        if(flag[i] == 1)
            printf("wins\n");
        else
            printf("losses\n");
    }
    return 0;
}