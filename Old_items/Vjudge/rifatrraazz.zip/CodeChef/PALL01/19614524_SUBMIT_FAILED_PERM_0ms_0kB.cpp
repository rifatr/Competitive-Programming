#include<stdio.h>
#include<string.h>

int main()
{
    int t, i;
    scanf("%d", &t);
    char s[10000];
    char r[10000];

    for(i = 0; i < t; i++){
        scanf("%s", s);
        strcpy(r, s);
        strrev(r);
        if(strcmp(s, r) == 0)
            printf("wins\n");
        else
            printf("losses\n");
    }

    return 0;
}
