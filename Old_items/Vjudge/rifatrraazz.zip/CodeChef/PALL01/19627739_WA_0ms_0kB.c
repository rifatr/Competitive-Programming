#include<stdio.h>
#include<string.h>

int main()
{
    int t, i, j, k, l;
    scanf("%d", &t);

    char s[10000], p[10000];
    int f[t];

    for(i = 0; i < t; i++)
        f[i] = 0;

    for(i = 0; i < t; i++){
        scanf("%s", s);

        //strcpy(p, s);
        //strrev(p);
        l = strlen(s);
        for(j = 0, k = l - 1; j < l, k >= 0; j++, k--){
            p[k] = s[j];
        }

        if(strcmp(s, p) == 0)
            f[i] = 1;
    }

    for(i = 0; i < t; i++){
        if(f[i] == 1)
            printf("wins\n");
        else
            printf("losses\n");
    }
}
