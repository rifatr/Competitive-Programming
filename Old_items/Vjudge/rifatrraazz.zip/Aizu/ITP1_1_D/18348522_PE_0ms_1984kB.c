#include<stdio.h>
int main()
{
    int S, h, x, m, s;
    scanf("%d", &S);
    h = S / 3600;
    x = S - h * 3600;
    m = x / 60;
    s = x - ( m * 60);
    printf("%d : %d : %d\n", h, m, s);
    return 0;
}
