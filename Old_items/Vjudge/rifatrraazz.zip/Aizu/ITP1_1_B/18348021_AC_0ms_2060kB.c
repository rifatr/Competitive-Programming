#include<stdio.h>
int main()
{
    int x;
    scanf("%d", &x);
    printf("%d\n", x*x*x);
    return 0;
    //1810024
}
