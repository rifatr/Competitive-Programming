#include<stdio.h>
int main()
{
    int a, b, x, y;
    scanf("%d%d", &a, &b);
    x = a * b;
    y = 2 * ( a + b);
    printf("%d %d", x, y);
    return 0;
}
