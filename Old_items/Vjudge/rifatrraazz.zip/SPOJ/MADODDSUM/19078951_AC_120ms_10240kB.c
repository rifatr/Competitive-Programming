#include<stdio.h>
int main()
{
    unsigned long int i, a, b, sum = 0;
    scanf("%lu %lu", &a, &b);
    for(i = a; i <= b; i++){
        if(i % 2 != 0)
            sum += i;
    }
    printf("%lu\n", sum);
    return 0; //raazz
}
