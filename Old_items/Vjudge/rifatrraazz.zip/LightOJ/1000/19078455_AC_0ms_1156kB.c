#include<stdio.h>
int main()
{
    int n, i, a, b;
    scanf("%d", &n);
    for(i = 1; i <= n; i++){
        //sum = 0;
        scanf("%d %d", &a, &b);
        //sum = a + b;
        printf("Case %d: %d\n", i, a + b);
    }
   /* for(i = 1; i <= n; i++){
        printf("Case %d: \n", i, a + b);
    }*/
    return 0;
}
