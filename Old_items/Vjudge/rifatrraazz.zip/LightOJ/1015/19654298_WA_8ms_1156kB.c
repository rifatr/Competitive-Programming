#include<stdio.h>

int main()
{
    int t, s, d;
    scanf("%d", &t);
    int i, j;

    for(i = 0; i < t; i++ )
    {
        scanf("\n %d", &s);
        int sum = 0;
        for(j = 0; j < s; j++){
            scanf("%d", &d);
            sum += d;
        }
        printf("Case %d: %d\n", i + 1, sum);
    }
    return 0;
}
