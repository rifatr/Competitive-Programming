#include<stdio.h>
int main()
{
    int n, i;
    float r;
    scanf("%d", &n);
    for(i = 1; i <= n; i++){
        scanf("%f", &r);
        printf("Case %d: %.2f\n", i, ((4 - 3.141592654) * r * r));
    } //rrraazz
    return 0;
}
