#include<stdio.h>
int main()
{
    int n, i;
    float r;
    scanf("%d", &n);
    for(i = 1; i <= n; i++){
        scanf("%f", &r);
        printf("Case %d: %.2f\n", i, (0.858407 * r * r));
    } //rrraazz
    return 0;
}
