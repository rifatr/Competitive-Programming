#include<stdio.h>

int main()
{
    signed long long int n;
    scanf("%lli", &n);
    printf("25\n");
}
