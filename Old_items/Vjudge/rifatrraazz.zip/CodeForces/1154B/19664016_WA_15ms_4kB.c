#include<stdio.h>

int main()
{
    int i, j = 1, k, d = 0, n, t;
    scanf("%d", &n);

    int a[n], u[n];
    for(i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }

    u[0] = a[0];
    for(i = 1; i < n; i++)
    {
        if(a[0] == a[i])
            continue;
        for(k = 1; k < j; k++)
        {
            if(a[i] == u[k])
                d += 1;
        }
        if(d == 0)
        {
            u[j] = a[i];
            j += 1;
        }
        d = 0;
    }

    if(j > 3)
        printf("-1\n");
    else
    {
        for(k = 0; k < j; k++)
        {
            for(i = k + 1; i < n; i++)
            {
                if(u[k] > u[i])
                {
                    t = u[k];
                    u[i] = u[k];
                    u[k] = t;
                }
            }
        }

        t = (u[j - 1] - u[0]) / 2;
        u[0] = u[0] + t;
        u[j - 1] = u[j - 1] - t;

        if(u[0] == u[1] || u[1] == u[2])
            printf("%d\n", t);
        else
            printf("-1\n");
    }

    return 0;
}
