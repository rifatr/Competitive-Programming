#include<stdio.h>

int main()
{
    int i, j = 1, k, d = 0, n, t;
    scanf("%d", &n);

    int a[n], u[n];
    for(i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }

    u[0] = a[0];
    for(i = 1; i < n; i++)
    {
        if(a[0] == a[i])
            continue;
        for(k = 1; k < j; k++)
        {
            if(a[i] == u[k])
                d += 1;
        }
        if(d == 0)
        {
            u[j] = a[i];
            j += 1;
        }
        d = 0;
    }

    for(k = 0; k < j; k++)
    {
        for(i = k + 1; i < n; i++)
        {
            if(u[k] > u[i])
            {
                t = u[k];
                u[i] = u[k];
                u[k] = t;
            }
        }
    }

    if(j == 1)
        printf("0\n");
    if(j == 2)
    {
        if((u[1] - u[0]) % 2 == 0)
            printf("%d\n", (u[1] - u[0]) / 2);
        else
            printf("%d\n", u[1] - u[0]);
    }
    if(j == 3)
    {
        if(u[1] - u[0] == u[2] - u[1])
            printf("%d\n", u[1] - u[0]);
        else
            printf("-1\n");
    }
    if(j > 3)
        printf("-1\n");

    return 0;
}
