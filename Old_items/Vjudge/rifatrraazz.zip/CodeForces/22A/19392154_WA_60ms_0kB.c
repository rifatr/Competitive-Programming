#include<stdio.h>
main()
{
    int n;
    scanf("%d", &n);
    int a[n], i;

    for(i = 0; i < n; i++)
        scanf("%d", &a[i]);

    int min = a[0];

    for(i = 1; i < n; i++){
        if(a[i] < min)
            min = a[i];
    }

    int second_min = a[1];

    for(i = 0; i < n; i++){
        if(a[i] < second_min && a[i] > min)
            second_min = a[i];
    }
    printf("%d\n", second_min);
}
