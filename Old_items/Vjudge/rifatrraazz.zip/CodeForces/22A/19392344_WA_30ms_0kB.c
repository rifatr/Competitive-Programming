#include<stdio.h>
int main()
{
    int n;
    scanf("%d", &n);
    int a[n], i, j, temp;

    for(i = 0; i < n; i++)
        scanf("%d", &a[i]);

    for(i = 0; i < n; i++){
        for(j = i + 1; j < n; j++)
        {
            if(a[j] < a[i])
            {
                temp = a[i];
                a[i] = a[j];
                a[j] = temp;
            }
        }
    }
    if(n == 1 || a[0] == a[n-1]){
        printf("NO\n");
    }
    else {
        printf("%d\n", a[1]);
    }
}
