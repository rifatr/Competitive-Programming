#include<stdio.h>

int main()
{
    int j, i, n, k, c = 0;
    scanf("%d %d", &n, &k);
    int a[n];
    for(i = 0; i < n; i++) {
    scanf("%d", &a[i]);
    }
    j = a[k];
    for(i = 0; i < n; i++) {
        if (a[i] >= j)
            c++;
    }
    if(a[0] == a[n-1]){
        printf("0\n");}
    else {
        printf("%d\n", c);}
    return 0;
}
