#include<stdio.h>

int main()
{
    int i, n, k, c = 0;
    scanf("%d %d", &n, &k);
    int a[n];
    for(i = 0; i < n; i++) {
    scanf("%d", &a[i]);
    }
    for(i = 0; i <= k; i++) {
//        if (a[i] > k)
            c++;
    }
    printf("%d\n", c);
    return 0;
}
