#include<stdio.h>

int main()
{
    unsigned long long a, b, m;
    scanf("%llu%llu%llu", &a, &b, &m);
    printf("%llu\n", (a + b) % m);
    return 0;
}
