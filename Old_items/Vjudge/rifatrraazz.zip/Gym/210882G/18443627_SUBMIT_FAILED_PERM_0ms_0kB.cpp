#include<stdio.h>

int main()
{
    unsigned long long int A, B, M;
    scanf("%llu%llu%llu", &A, &B,&M);
    printf("%llu\n", (A * B) % M);
    return 0;
}
