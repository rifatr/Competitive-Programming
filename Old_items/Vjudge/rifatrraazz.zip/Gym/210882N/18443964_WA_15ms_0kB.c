#include<stdio.h>
int main()
{
    unsigned long long n, s;
    scanf("%llu", &n);

    s = n * ( n + 1 ) / 2;

    printf("%llu", s);

    return 0;
}
