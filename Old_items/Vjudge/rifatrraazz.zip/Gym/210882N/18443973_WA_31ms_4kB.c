#include<stdio.h>
int main()
{
    unsigned long long n;
    long long int s;
    scanf("%llu", &n);

    s = n * ( n + 1 ) / 2;

    printf("%lli\n", s);

    return 0;
}
