#include<stdio.h>

int main()
{
    printf("RUET-e kono ragging nai, egula media er srishti\n"); \\rraazz
    return 0;
}
