#include<stdio.h>

int main()
{
    printf("RUET-e kono ragging nai, egula media er srishti\n"); \\rifatraazz
    return 0;
}
