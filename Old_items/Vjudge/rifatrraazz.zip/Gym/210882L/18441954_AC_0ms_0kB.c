#include<stdio.h>
int main()
{
    char c, S, H;
    scanf("%c", &c);

    if ( c == 'S') {
        printf("Ragging er sathe jorito thakle paap hobe paap, paapider shasti howa uchit\n");
    }
    else if ( c == 'H') {
        printf("RUET-e kono ragging nai, egula media er srishti\n");
    }

    return 0;
}
