#include<stdio.h>
int main()
{
    unsigned long long int N, M;
    scanf("%llu%llu", &N, &M);

    printf("%llu\n", N%M);

    return 0;
}
