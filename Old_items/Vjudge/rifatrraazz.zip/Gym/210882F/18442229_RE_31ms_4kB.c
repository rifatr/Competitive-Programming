#include<stdio.h>
int main()
{
    long long int N, M;
    scanf("%lli%lli", &N, &M);

    printf("%lli\n", N%M);

    return 0;
}
