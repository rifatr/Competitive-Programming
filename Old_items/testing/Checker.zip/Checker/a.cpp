#include<bits/stdc++.h>
using namespace std;

#define ll long long
#define deb(x) cout << #x << "=" << x << endl
#define deb2(x, y) cout << #x << "=" << x << " , " << #y << "=" << y << endl
#define _  ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
#define ff first
#define ss second
#define pb push_back
#define pp pop_back

bool vis[1005];

void solve()
{
    ll n, m;
    cin >> n;
    ll ar[n];
    for(ll i=0 ; i<n ; i++) cin >> ar[i];
    vector<ll>res;
    for(ll i=n; i>=1 ; i--)
    {
      ll mx = 0, pos = -1;
      for(ll j=0 ; j<n ; j++)
      {
        if(!vis[j] && ar[j]%i == 0)
        {
          mx = ar[j];
          pos = j;
        }
      }
      vis[pos] = 1;
      res.push_back(mx/i);
    }
    
    for(ll i=(ll)res.size()-1 ; i>=0 ; i--) cout << res[i] << ' ';
    cout << '\n';
    
    memset(vis, 0, sizeof(vis));
}

int main()
{_
    int t = 1, cs = 1;

    cin >> t;

    while (t--)
    {
        solve();
    }

    return 0;
}
