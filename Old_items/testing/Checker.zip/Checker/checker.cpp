#include <bits/stdc++.h>
#include "testlib.h"

using namespace std;

int main()
{
	FILE *ou, *an;
	ou = fopen("ouf", "r");
	//an = fopen("ans", "r");
	
	int t; cin >> t; //take input from STDIN
	for(int z = 1; z <= t; z++)
	{
		//int xo , yo, xa, ya;
		//fscanf(ou, "%d %d", &xo, & yo); // take input from output file
		//fscanf(an, "%d %d", &xa, & ya); // take input from judge sol file
		
		int n; cin >> n;
		int out[n], in[n];
		for(int i = 0; i < n; i++) cin >> in[i];
		
		for(int i = 0; i < n; i++) fscanf(ou, "%d", &out[i]);
		for(int i = 0; i < n; i++) out[i] *= (i + 1);
		sort(out, out + n);
		
		for(int i = 0; i < n; i++) {
			if(in[i] != out[i]) {
				printf("Case %d, wanted %d, got %d\n", z, in[i], out[i]);
			}
		}
		
		//if(xo + yo != xa + ya) 
			//printf("Case %d, wanted %d, got %d", z, xa + ya, xo + yo);
	}
	
	printf("ac\n");
}
