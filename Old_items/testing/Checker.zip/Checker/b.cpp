#include <bits/stdc++.h>

using namespace std;

int main()
{
	int t; cin >> t;

	while (t--)
	{
		pair <int, int> a[4];
		for (int i = 0; i < 4; i++) cin >> a[i].first, a[i].second = i;

		sort(a, a + 4);
		cout << a[3].second << ' ' << a[2].second << '\n';
	}
}