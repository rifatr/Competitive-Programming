#include <bits/stdc++.h>
#include "testlib.h"

using namespace std;

int main(int argc, char* argv[])
{
	int t = rnd.next(1, 1);
	println(t);
	
	while(t--)
	{
		int n = rnd.next(1, 20);
		int a[n];
		for(int i = 0; i < n; i++) a[i] = rnd.next(1, 100);
		for(int i = 0; i < n; i++) a[i] *= (i + 1);
		
		println(n);
		sort(a, a + n);
		for(int i = 0; i < n; i++) cout << a[i] << ' ';
		cout << '\n';
	}
}
